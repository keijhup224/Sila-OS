import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Activity, ArrowDownRight, ArrowLeft, ArrowRight, ArrowUpRight, Baby,
  BookOpen, BriefcaseBusiness, Building2, CalendarDays, CarFront, Check,
  CheckCircle2, ChevronDown, Clock3, Compass, GraduationCap, Heart,
  HeartHandshake, HelpCircle, House, Languages, Landmark, Map, MapPin,
  Menu, MessageCircle, Search, Send, Settings, ShieldCheck, Sparkles,
  Stethoscope, Ticket, UserRound, Users, Utensils, Wallet, X, Zap,
  Globe2, Bookmark, Bell, ExternalLink, Copy, RefreshCw, Leaf, Bus,
  FileText, IdCard, Plane, Siren, HandHeart
} from "lucide-react";
import "./styles.css";

const services = [
  { id:"id", title:"Emirates ID", category:"Government", desc:"Application and renewal guidance, required documents, and official channels.", icon:IdCard, tags:["resident","visitor"], color:"blue", action:"Check ID requirements" },
  { id:"passport", title:"Passport services", category:"Government", desc:"Find the relevant passport application or renewal channel for your circumstances.", icon:FileText, tags:["resident","visitor"], color:"violet", action:"Explore passport services" },
  { id:"baby", title:"Newborn birth certificate", category:"Family", desc:"Understand birth registration steps and the documents that may be required.", icon:Baby, tags:["resident","visitor"], color:"pink", action:"Build a newborn checklist" },
  { id:"license", title:"Driving licence renewal", category:"Transport", desc:"Review renewal guidance and locate the relevant official transport authority.", icon:CarFront, tags:["resident","visitor"], color:"orange", action:"View driving guidance" },
  { id:"vehicle", title:"Vehicle registration", category:"Transport", desc:"Explore vehicle registration, inspection, and renewal guidance.", icon:CarFront, tags:["resident","visitor"], color:"orange", action:"Explore vehicle services" },
  { id:"health", title:"Healthcare finder", category:"Healthcare", desc:"Discover clinics, hospitals, pharmacies, and health programmes.", icon:Stethoscope, tags:["resident","visitor"], color:"green", action:"Find healthcare" },
  { id:"blood", title:"Blood donation drives", category:"Community", desc:"Discover donation campaigns and organiser information.", icon:Activity, tags:["resident","visitor"], color:"red", action:"Explore donation drives" },
  { id:"food", title:"Food support & sharing", category:"Community", desc:"Connect with approved food support programmes and surplus-food partners.", icon:Utensils, tags:["resident","visitor"], color:"green", action:"Explore food support" },
  { id:"volunteer", title:"Volunteer opportunities", category:"Community", desc:"Find community events, environmental projects, and ways to help.", icon:HeartHandshake, tags:["resident","visitor"], color:"pink", action:"Find volunteering" },
  { id:"study", title:"Student Study Hub", category:"Education", desc:"Create revision plans, practise topics, and discover learning resources.", icon:GraduationCap, tags:["resident","visitor"], color:"violet", action:"Open Study Hub" },
  { id:"tutors", title:"Tutors & learning", category:"Education", desc:"Explore tutors and learning options by subject and format.", icon:BookOpen, tags:["resident","visitor"], color:"blue", action:"Find tutors" },
  { id:"business", title:"Local businesses", category:"Local Life", desc:"Explore local services, garages, shops, and useful places.", icon:Building2, tags:["resident","visitor"], color:"orange", action:"Explore businesses" },
  { id:"travel", title:"Explore the UAE", category:"Visitor Essentials", desc:"Discover attractions, family activities, and local experiences.", icon:Compass, tags:["visitor","resident"], color:"violet", action:"Explore places" },
  { id:"transport", title:"Getting around", category:"Visitor Essentials", desc:"Find transport information, parking guidance, and useful travel links.", icon:Bus, tags:["visitor","resident"], color:"blue", action:"Explore transport" },
  { id:"residency", title:"Visa & residency information", category:"Government", desc:"Find official information relevant to your situation and status.", icon:Landmark, tags:["resident","visitor"], color:"blue", action:"Check official information" },
  { id:"scholarships", title:"Scholarships & opportunities", category:"Education", desc:"Explore scholarships, internships, competitions, and youth programmes.", icon:BriefcaseBusiness, tags:["resident","visitor"], color:"green", action:"Find opportunities" }
];

const visitorOrder = ["travel","health","transport","blood","volunteer","business","food","residency","study","tutors","id","passport","baby","license","vehicle","scholarships"];
const residentOrder = ["id","passport","baby","license","vehicle","health","blood","food","volunteer","study","tutors","business","residency","scholarships","travel","transport"];
const categories = ["All services","Government","Healthcare","Community","Education","Local Life","Transport","Family","Visitor Essentials"];

const translations = {
  en: { welcome:"Everything you need in the UAE, connected.", subtitle:"Your UAE life assistant", phone:"Phone number", send:"Send demo OTP", language:"Choose your language", account:"How are you using Sila?", resident:"UAE Resident", visitor:"Visitor / Tourist", continue:"Continue to Sila", dashboard:"Your day, made simpler.", search:"What can I help you with today?", all:"All services", assistant:"Ask Sila AI", map:"Explore map", saved:"Saved", profile:"Profile", services:"Services", community:"Community", study:"Study Hub", home:"Home", greeting:"Welcome to Sila", explore:"Explore services", upcoming:"Your quick access", recommended:"Recommended for you", viewAll:"View all", signOut:"Sign out" },
  ar: { welcome:"كل ما تحتاجه في الإمارات، في مكان واحد.", subtitle:"مساعدك للحياة في الإمارات", phone:"رقم الهاتف", send:"إرسال رمز تجريبي", language:"اختر لغتك", account:"كيف ستستخدم صلة؟", resident:"مقيم في الإمارات", visitor:"زائر / سائح", continue:"المتابعة إلى صلة", dashboard:"يومك أصبح أسهل.", search:"كيف يمكنني مساعدتك اليوم؟", all:"كل الخدمات", assistant:"اسأل مساعد صلة", map:"استكشف الخريطة", saved:"المحفوظات", profile:"الملف الشخصي", services:"الخدمات", community:"المجتمع", study:"مركز الدراسة", home:"الرئيسية", greeting:"مرحباً بك في صلة", explore:"استكشف الخدمات", upcoming:"الوصول السريع", recommended:"موصى به لك", viewAll:"عرض الكل", signOut:"تسجيل الخروج" }
};

function App() {
  const [stage, setStage] = useState("phone");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [language, setLanguage] = useState("en");
  const [accountType, setAccountType] = useState("resident");
  const [page, setPage] = useState("Home");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All services");
  const [saved, setSaved] = useState([]);
  const [selected, setSelected] = useState(null);
  const [chatInput, setChatInput] = useState("");
  const [messages, setMessages] = useState([
    { role:"assistant", text:"Hi! I'm Sila, your UAE life assistant. Tell me what you're trying to do and I'll help you find the right next steps." }
  ]);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [notice, setNotice] = useState("");
  const [tasks, setTasks] = useState(["Choose your preferred language","Explore a service"]);
  const t = translations[language];
  const rtl = language === "ar";

  const orderedServices = useMemo(() => {
    const ids = accountType === "visitor" ? visitorOrder : residentOrder;
    return ids.map(id => services.find(s => s.id === id)).filter(Boolean);
  }, [accountType]);

  const filteredServices = useMemo(() => orderedServices.filter(s => {
    const matchesCategory = category === "All services" || s.category === category;
    const text = `${s.title} ${s.desc} ${s.category}`.toLowerCase();
    return matchesCategory && text.includes(query.toLowerCase());
  }), [orderedServices, category, query]);

  function sendOtp() {
    if (phone.replace(/\D/g, "").length < 7) {
      setNotice("Please enter a valid phone number to continue.");
      return;
    }
    setNotice("Demo mode: use OTP 123456. No SMS was sent.");
    setStage("otp");
  }
  function verifyOtp() {
    if (otp === "123456") {
      setStage("account");
      setNotice("");
    } else {
      setNotice("That demo OTP isn't correct. Enter 123456 to continue.");
    }
  }
  function enterApp() {
    setStage("app");
    setPage("Home");
    setNotice("");
  }
  function toggleSave(id) {
    setSaved(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  }
  function askSila(text = chatInput) {
    const trimmed = text.trim();
    if (!trimmed) return;
    const userMessage = { role:"user", text:trimmed };
    const lower = trimmed.toLowerCase();
    let response = "I can help you break this into steps. First, I'll identify the relevant service, then show the information to verify, documents to prepare, and the official channel to use. For accurate requirements, always check the linked authority's latest guidance.";
    if (/baby|newborn|birth certificate/.test(lower)) response = "For a newborn, your next steps may include birth notification and registration, obtaining a birth certificate, and checking passport and residency requirements that apply to your family's circumstances. I can help you build a checklist. Requirements vary, so confirm the exact steps with the relevant UAE authority.";
    else if (/emirates id|id renewal|id card/.test(lower)) response = "Let's start with Emirates ID guidance. The exact process depends on your status and application type. I'll help you identify the relevant official channel, check what information you may need, and make a checklist. This demo doesn't access government records or submit applications.";
    else if (/blood|donat/.test(lower)) response = "I can help you find blood donation campaigns. Check the Blood Donation Drives service for organiser details and location information. Confirm current dates, appointment availability, and donor eligibility with the organiser before travelling.";
    else if (/food|hungry|surplus/.test(lower)) response = "You can explore Food Support & Sharing for approved community programmes and partner organisations. For urgent needs, contact a verified local support organisation directly. This demo does not distribute food or verify eligibility.";
    else if (/study|exam|revision/.test(lower)) response = "Let's make a study plan. Tell me your subject, exam date, and the topics you need to cover. I can suggest a revision schedule, practice questions, and flashcards.";
    else if (/visitor|tour|visit|attraction/.test(lower)) response = "For visitors, I can help organise attractions, transport information, nearby essentials, and official visitor guidance. Tell me which emirate you're exploring and what you enjoy. Check live opening hours and official requirements before making plans.";
    else if (/license|driving|car/.test(lower)) response = "For driving or vehicle services, the correct process depends on your licence, vehicle, and circumstances. Start with the relevant official transport authority. I can organise a checklist and help you find nearby service providers, but this demo can't renew a licence.";
    setMessages(prev => [...prev, userMessage, { role:"assistant", text:response }]);
    setChatInput("");
    setPage("AI Assistant");
  }
  function openService(s) {
    setSelected(s);
    setPage("Services");
  }
  function navigate(item) {
    setPage(item);
    setMobileMenu(false);
    setSelected(null);
  }

  if (stage !== "app") {
    return <div className={`onboarding ${rtl ? "rtl" : ""}`}>
      <div className="onboard-glow glow-one"></div><div className="onboard-glow glow-two"></div>
      <div className="onboard-top">
        <div className="brand"><div className="brand-mark"><Sparkles size={23}/></div><div><strong>sila<span>OS</span></strong><small>{t.subtitle}</small></div></div>
        <label className="language-select"><Languages size={17}/><select value={language} onChange={e => setLanguage(e.target.value)} aria-label="Language"><option value="en">English</option><option value="ar">العربية</option></select><ChevronDown size={14}/></label>
      </div>
      <div className="onboard-layout">
        <section className="welcome-copy">
          <div className="eyebrow"><Sparkles size={15}/> ONE CONNECTION. MANY POSSIBILITIES.</div>
          <h1>{t.welcome}</h1>
          <p>Government services, healthcare, education, and community support — personalised around you.</p>
          <div className="welcome-points"><div><CheckCircle2 size={18}/> Personalised service guidance</div><div><CheckCircle2 size={18}/> Discover useful places nearby</div><div><CheckCircle2 size={18}/> One assistant for everyday life</div></div>
          <div className="onboard-art"><div className="art-orbit orbit-a"></div><div className="art-orbit orbit-b"></div><div className="art-center"><Sparkles size={45}/><span>sila</span></div><div className="float-icon fi-one"><Landmark/></div><div className="float-icon fi-two"><HeartPulseIcon/></div><div className="float-icon fi-three"><MapPin/></div><div className="float-icon fi-four"><GraduationCap/></div></div>
        </section>
        <section className="auth-card">
          <div className="step-indicator"><span className={stage==="phone"?"active":""}></span><span className={stage==="otp"?"active":""}></span><span className={stage==="account"?"active":""}></span></div>
          {stage==="phone" && <>
            <div className="card-icon"><ShieldCheck size={25}/></div><h2>Welcome to Sila</h2><p className="muted">Start with your phone number to personalise your experience.</p>
            <label className="field-label">{t.phone}</label>
            <div className="phone-input"><span className="country-code">🇦🇪 +971</span><input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="50 123 4567" inputMode="tel" onKeyDown={e=>e.key==="Enter"&&sendOtp()}/></div>
            <button className="primary-btn full" onClick={sendOtp}>{t.send}<ArrowRight size={17}/></button>
            <div className="privacy-note"><ShieldCheck size={15}/> Demo onboarding. No phone number is sent or stored.</div>
          </>}
          {stage==="otp" && <>
            <button className="back-btn" onClick={()=>{setStage("phone");setNotice("")}}><ArrowLeft size={16}/> Change phone number</button>
            <div className="card-icon"><MessageCircle size={25}/></div><h2>Verify your number</h2><p className="muted">Enter the six-digit demo code to continue.</p>
            <label className="field-label">One-time passcode</label>
            <input className="otp-input" value={otp} onChange={e=>setOtp(e.target.value.replace(/\D/g,"").slice(0,6))} placeholder="123456" inputMode="numeric" maxLength={6} onKeyDown={e=>e.key==="Enter"&&verifyOtp()}/>
            <div className="demo-hint"><Zap size={15}/> Demo OTP: <strong>123456</strong></div>
            <button className="primary-btn full" onClick={verifyOtp}>Verify & continue <ArrowRight size={17}/></button>
          </>}
          {stage==="account" && <>
            <div className="card-icon"><UserRound size={25}/></div><h2>Make Sila yours</h2><p className="muted">Choose your language and how you're using Sila today.</p>
            <label className="field-label">{t.language}</label>
            <div className="language-options"><button className={language==="en"?"language-option chosen":"language-option"} onClick={()=>setLanguage("en")}><span>🇬🇧</span> English {language==="en"&&<Check size={16}/>}</button><button className={language==="ar"?"language-option chosen":"language-option"} onClick={()=>setLanguage("ar")}><span>🇦🇪</span> العربية {language==="ar"&&<Check size={16}/>}</button></div>
            <label className="field-label">{t.account}</label>
            <div className="account-options">
              <button className={accountType==="resident"?"account-option chosen":"account-option"} onClick={()=>setAccountType("resident")}><div className="account-icon"><House size={21}/></div><div><strong>{t.resident}</strong><small>Everyday services, documents & tasks</small></div>{accountType==="resident"&&<CheckCircle2 className="account-check" size={19}/>}</button>
              <button className={accountType==="visitor"?"account-option chosen":"account-option"} onClick={()=>setAccountType("visitor")}><div className="account-icon visitor-icon"><Plane size={21}/></div><div><strong>{t.visitor}</strong><small>Explore, transport & visitor essentials</small></div>{accountType==="visitor"&&<CheckCircle2 className="account-check" size={19}/>}</button>
            </div>
            <button className="primary-btn full" onClick={enterApp}>{t.continue}<ArrowRight size={17}/></button>
            <p className="tiny-note">You can change your preferences later. Restricted services may require official eligibility checks.</p>
          </>}
          {notice && <div className="notice"><HelpCircle size={15}/>{notice}</div>}
          <div className="auth-footer">By continuing, you agree to use Sila's demo responsibly.</div>
        </section>
      </div>
      <footer className="onboard-footer"><span>© 2026 Sila OS</span><span>Made to make life simpler <Heart size={13}/></span><span>Privacy-first by design</span></footer>
    </div>;
  }

  const navItems = [
    {name:"Home", icon:House}, {name:"AI Assistant",icon:MessageCircle}, {name:"Services",icon:Landmark},
    {name:"Live Map",icon:Map}, {name:"Healthcare",icon:Activity}, {name:"Community",icon:HeartHandshake},
    {name:"Study Hub",icon:GraduationCap}, {name:"Local Life",icon:Building2}, {name:"Saved",icon:Bookmark}
  ];
  const pageTitle = page === "Home" ? (accountType==="visitor"?"Your UAE adventure, made simpler.":t.dashboard) : page;
  const activeLabel = accountType === "visitor" ? "VISITOR EXPERIENCE" : "RESIDENT EXPERIENCE";

  function renderServiceCard(s) {
    const Icon = s.icon;
    return <article className="service-card" key={s.id}>
      <div className={`service-icon ${s.color}`}><Icon size={22}/></div>
      <button className={`save-btn ${saved.includes(s.id)?"is-saved":""}`} onClick={()=>toggleSave(s.id)} aria-label="Save service"><Bookmark size={17} fill={saved.includes(s.id)?"currentColor":"none"}/></button>
      <div className="service-category">{s.category}</div><h3>{s.title}</h3><p>{s.desc}</p>
      <button className="text-link" onClick={()=>openService(s)}>{s.action}<ArrowUpRight size={16}/></button>
    </article>;
  }

  return <div className={`app-shell ${rtl?"rtl":""}`}>
    <aside className={`sidebar ${mobileMenu?"sidebar-open":""}`}>
      <div className="brand sidebar-brand"><div className="brand-mark"><Sparkles size={22}/></div><div><strong>sila<span>OS</span></strong><small>Your UAE life assistant</small></div><button className="close-menu" onClick={()=>setMobileMenu(false)}><X/></button></div>
      <div className="sidebar-label">WORKSPACE</div>
      <nav>{navItems.map(item=>{const Icon=item.icon;return <button key={item.name} className={`nav-item ${page===item.name?"nav-active":""}`} onClick={()=>navigate(item.name)}><Icon size={19}/><span>{item.name==="Home"?t.home:item.name==="Services"?t.services:item.name==="Saved"?t.saved:item.name}</span>{item.name==="AI Assistant"&&<span className="nav-new">AI</span>}</button>})}</nav>
      <div className="sidebar-bottom"><div className="help-card"><div className="help-spark"><Sparkles size={18}/></div><strong>Need a little help?</strong><p>Ask Sila to find the right next step for you.</p><button onClick={()=>navigate("AI Assistant")}>Ask Sila <ArrowRight size={14}/></button></div><button className="nav-item" onClick={()=>navigate("Profile")}><Settings size={19}/><span>Settings & profile</span></button><div className="user-mini"><div className="avatar">{accountType==="visitor"?"V":"S"}</div><div className="user-mini-text"><strong>{accountType==="visitor"?"UAE Visitor":"Sila Explorer"}</strong><small>{accountType==="visitor"?"Visitor / Tourist":"UAE Resident"}</small></div><button onClick={()=>{setStage("phone");setOtp("");setNotice("")}} title="Sign out"><ArrowUpRight size={17}/></button></div></div>
    </aside>
    {mobileMenu&&<div className="mobile-scrim" onClick={()=>setMobileMenu(false)}></div>}
    <main className="main-area">
      <header className="topbar"><div className="topbar-left"><button className="menu-toggle" onClick={()=>setMobileMenu(true)}><Menu/></button><div className="breadcrumb">Sila OS <span>/</span> <strong>{page}</strong></div></div><div className="topbar-right"><div className="account-pill"><span className={`status-dot ${accountType}`}></span>{activeLabel}<ChevronDown size={14}/><select aria-label="Switch account type" value={accountType} onChange={e=>setAccountType(e.target.value)}><option value="resident">Resident</option><option value="visitor">Visitor</option></select></div><button className="icon-button" title="Notifications" onClick={()=>setNotice("You're all caught up. This demo has no live notifications.")}><Bell size={19}/></button><button className="profile-button" onClick={()=>navigate("Profile")}><span className="avatar">{accountType==="visitor"?"V":"S"}</span></button></div></header>
      <div className="page-content">
        {page==="Home"&&<>
          <section className="hero-banner"><div className="hero-copy"><div className="eyebrow light"><Sparkles size={14}/>{accountType==="visitor"?"YOUR UAE JOURNEY STARTS HERE":"YOUR PERSONAL SERVICE COMPANION"}</div><h1>{pageTitle}</h1><p>{accountType==="visitor"?"Discover places, useful services, and local experiences — all in one place.":"Your services, your community, your next step — all in one place."}</p><button className="hero-search" onClick={()=>navigate("AI Assistant")}><Search size={19}/><span>{t.search}</span><kbd>Ask AI</kbd></button><div className="hero-foot"><span><ShieldCheck size={14}/> Trusted guidance</span><span><Zap size={14}/> Personalised for you</span></div></div><div className="hero-art"><div className="hero-circle circle-one"></div><div className="hero-circle circle-two"></div><div className="hero-glass"><Sparkles size={46}/><span>hello, sila</span><small>Here to help you</small></div><div className="hero-float hf-one"><MapPin size={18}/><span>Nearby places</span></div><div className="hero-float hf-two"><CheckCircle2 size={18}/><span>Next steps, simplified</span></div></div></section>
          <section className="quick-section"><div className="section-heading"><div><span className="eyebrow">YOUR SHORTCUTS</span><h2>{t.upcoming}</h2></div><button className="subtle-link" onClick={()=>navigate("Services")}>{t.viewAll}<ArrowRight size={16}/></button></div><div className="quick-grid">
            {(accountType==="visitor"?[
              {title:"Explore the UAE",desc:"Places & experiences",icon:Compass,color:"violet",page:"Services",query:""},
              {title:"Nearby essentials",desc:"Healthcare & useful places",icon:MapPin,color:"green",page:"Live Map"},
              {title:"Getting around",desc:"Transport information",icon:Bus,color:"blue",page:"Services",q:"transport"},
              {title:"Blood donation",desc:"Find community drives",icon:Activity,color:"red",page:"Community"}
            ]:[
              {title:"Identity documents",desc:"ID & passport guidance",icon:IdCard,color:"blue",page:"Services",q:"Emirates ID"},
              {title:"Family services",desc:"Newborn & family tasks",icon:Baby,color:"pink",page:"Services",q:"newborn"},
              {title:"Healthcare",desc:"Find health services",icon:Stethoscope,color:"green",page:"Healthcare"},
              {title:"Community support",desc:"Food & volunteering",icon:HeartHandshake,color:"orange",page:"Community"}
            ]).map((q,i)=>{const Icon=q.icon;return <button className="quick-card" key={q.title} onClick={()=>{navigate(q.page);if(q.q)setQuery(q.q)}}><div className={`quick-icon ${q.color}`}><Icon size={21}/></div><div><strong>{q.title}</strong><small>{q.desc}</small></div><ArrowUpRight size={16} className="quick-arrow"/></button>})}
          </div></section>
          <section className="section-block"><div className="section-heading"><div><span className="eyebrow">CURATED FOR YOU</span><h2>{t.recommended}</h2><p className="section-subtitle">{accountType==="visitor"?"Useful essentials and experiences for your stay.":"A few useful places to start today."}</p></div><button className="subtle-link" onClick={()=>navigate("Services")}>{t.viewAll}<ArrowRight size={16}/></button></div><div className="service-grid">{orderedServices.slice(0,3).map(renderServiceCard)}</div></section>
          <section className="lower-grid"><div className="map-preview panel"><div className="panel-heading"><div><span className="eyebrow">FIND YOUR WAY</span><h2>Explore the UAE</h2></div><button className="icon-button" onClick={()=>navigate("Live Map")}><ArrowUpRight size={17}/></button></div><div className="map-art"><div className="map-road road-a"></div><div className="map-road road-b"></div><div className="map-road road-c"></div><div className="map-water"></div>{[[22,32],[55,22],[68,53],[37,68],[79,31]].map((p,i)=><div key={i} className={`map-pin pin-${i}`} style={{left:p[0]+"%",top:p[1]+"%"}}><MapPin size={20} fill="currentColor"/></div>)}<div className="map-label">UAE · Explore nearby</div></div><button className="primary-btn map-button" onClick={()=>navigate("Live Map")}>Open interactive map <ArrowRight size={16}/></button></div><div className="assistant-preview panel"><div className="assistant-orb"><Sparkles size={28}/></div><span className="eyebrow">YOUR PERSONAL AI</span><h2>Meet Sila AI</h2><p>Ask a question in your own words. Get clear next steps, useful links, and a little less stress.</p><div className="suggestion-list"><button onClick={()=>askSila("I need help finding the right government service.")}>Help me find a service <ArrowRight size={14}/></button><button onClick={()=>askSila("Find blood donation drives.")}>Find blood donation drives <ArrowRight size={14}/></button></div><button className="primary-btn full" onClick={()=>navigate("AI Assistant")}>Chat with Sila <MessageCircle size={16}/></button></div></section>
        </>}
        {page==="AI Assistant"&&<section className="content-page"><div className="page-intro"><span className="eyebrow"><Sparkles size={14}/> YOUR PERSONAL GUIDE</span><h1>Ask Sila AI</h1><p>Tell me what you need. I'll help you find a service and understand the next steps.</p></div><div className="chat-layout"><div className="chat-panel panel"><div className="chat-head"><div className="assistant-orb small-orb"><Sparkles size={20}/></div><div><strong>Sila Assistant</strong><small><span className="status-dot"></span> Demo guidance mode</small></div><button className="icon-button" onClick={()=>setMessages([{role:"assistant",text:"Hi! I'm Sila, your UAE life assistant. Tell me what you're trying to do and I'll help you find the right next steps."}])}><RefreshCw size={17}/></button></div><div className="messages">{messages.map((m,i)=><div key={i} className={`message-row ${m.role}`}><div className="message-avatar">{m.role==="assistant"?<Sparkles size={16}/>:<UserRound size={16}/>}</div><div className="message-bubble">{m.text}</div></div>)}</div><div className="chat-suggestions"><button onClick={()=>askSila("I need to renew my Emirates ID.")}>Renew my ID</button><button onClick={()=>askSila("I just had a newborn baby.")}>Newborn checklist</button><button onClick={()=>askSila("Find blood donation drives.")}>Blood donation</button></div><form className="chat-compose" onSubmit={e=>{e.preventDefault();askSila()}}><input value={chatInput} onChange={e=>setChatInput(e.target.value)} placeholder="Ask anything about services..." /><button className="send-btn" aria-label="Send message"><Send size={18}/></button></form><p className="chat-disclaimer">Sila's responses are prototype guidance, not official decisions. Verify requirements with the relevant authority.</p></div><aside className="chat-side panel"><h3>Try asking</h3>{["I just had a baby. What should I do?","Where can I donate blood?","Help me plan my exam revision.","I'm visiting the UAE. What should I know?"].map(s=><button className="prompt-card" key={s} onClick={()=>askSila(s)}><MessageCircle size={17}/><span>{s}</span><ArrowUpRight size={15}/></button>)}<div className="trust-note"><ShieldCheck size={19}/><div><strong>Helpful, with transparency</strong><p>Always verify official requirements and eligibility before applying.</p></div></div></aside></div></section>}
        {page==="Services"&&<section className="content-page"><div className="page-intro"><span className="eyebrow"><Landmark size={14}/> SERVICE DIRECTORY</span><h1>Discover services</h1><p>One place to explore government services and everyday support.</p></div><div className="search-toolbar"><div className="search-field"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search services, documents, or support..."/>{query&&<button onClick={()=>setQuery("")}><X size={16}/></button>}</div><label className="filter-select"><span>Category</span><select value={category} onChange={e=>setCategory(e.target.value)}>{categories.map(c=><option key={c}>{c}</option>)}</select><ChevronDown size={15}/></label></div><div className="results-line">{filteredServices.length} services and resources <span>·</span> Sorted for {accountType==="visitor"?"visitors":"residents"}</div>{filteredServices.length?<div className="service-grid all-services">{filteredServices.map(renderServiceCard)}</div>:<div className="empty-state"><Search size={28}/><h3>No matches yet</h3><p>Try another search or choose a different category.</p><button className="secondary-btn" onClick={()=>{setQuery("");setCategory("All services")}}>Clear filters</button></div>}</section>}
        {page==="Live Map"&&<section className="content-page"><div className="page-intro"><span className="eyebrow"><MapPin size={14}/> DISCOVER NEARBY</span><h1>Your UAE map</h1><p>Explore useful categories and open relevant location information.</p></div><div className="map-page-grid"><div className="large-map"><div className="map-art map-art-large"><div className="map-road road-a"></div><div className="map-road road-b"></div><div className="map-road road-c"></div><div className="map-water"></div>{[[18,30],[42,52],[67,27],[74,65],[31,78],[85,43],[52,20]].map((p,i)=><button key={i} className={`map-pin map-pin-button pin-${i%5}`} style={{left:p[0]+"%",top:p[1]+"%"}} title={["Healthcare","Community","Government","Local business","Donation drive"][i%5]} onClick={()=>setNotice(["Healthcare","Community","Government","Local business","Donation drive"][i%5]+" — demo map marker. Connect a live map and verified location dataset to show real directions.")}><MapPin size={23} fill="currentColor"/></button>)}<div className="map-label">UAE · Illustrative map preview</div></div><div className="map-legend"><span><i className="legend-dot blue-dot"></i> Government</span><span><i className="legend-dot green-dot"></i> Healthcare</span><span><i className="legend-dot pink-dot"></i> Community</span><span><i className="legend-dot orange-dot"></i> Local life</span></div></div><div className="location-list panel"><h3>Explore categories</h3><p className="muted">Select a category to discover relevant resources.</p>{[{name:"Healthcare & clinics",icon:Stethoscope,color:"green",q:"health"},{name:"Blood donation drives",icon:Activity,color:"red",q:"blood"},{name:"Volunteering",icon:HeartHandshake,color:"pink",q:"volunteer"},{name:"Government centres",icon:Landmark,color:"blue",q:"Government"},{name:"Local businesses",icon:Building2,color:"orange",q:"business"}].map(item=>{const Icon=item.icon;return <button className="location-item" key={item.name} onClick={()=>{setQuery(item.q);setCategory("All services");navigate("Services")}}><span className={`quick-icon ${item.color}`}><Icon size={18}/></span><span><strong>{item.name}</strong><small>Browse related resources</small></span><ArrowRight size={16}/></button>})}<div className="map-warning"><HelpCircle size={17}/><span>Map markers are illustrative demo data, not verified live locations.</span></div></div></div></section>}
        {page==="Healthcare"&&<section className="content-page"><div className="page-intro"><span className="eyebrow"><Activity size={14}/> HEALTH & WELLBEING</span><h1>Healthcare, made easier</h1><p>Find health resources, understand service options, and discover community health initiatives.</p></div><div className="feature-banner health-banner"><div className="feature-emoji"><Stethoscope size={30}/></div><div><h2>Find the right place to start</h2><p>Explore healthcare resources and verify current services with official providers.</p></div><button className="secondary-btn" onClick={()=>{setQuery("health");navigate("Services")}}>Explore healthcare <ArrowRight size={16}/></button></div><div className="service-grid">{orderedServices.filter(s=>["health","blood"].includes(s.id)).map(renderServiceCard)}{[{id:"emergency",title:"Emergency information",category:"Healthcare",desc:"Find official emergency contacts and urgent-care guidance.",icon:Siren,color:"red",action:"View official guidance"},{id:"screening",title:"Screening & prevention",category:"Healthcare",desc:"Explore screening, vaccination, and public health programmes.",icon:Heart,color:"green",action:"Explore programmes"}].map(renderServiceCard)}</div><p className="medical-note"><ShieldCheck size={16}/> This directory is informational and does not replace medical advice. For emergencies, contact local emergency services.</p></section>}
        {page==="Community"&&<section className="content-page"><div className="page-intro"><span className="eyebrow"><HeartHandshake size={14}/> GOOD THINGS, CONNECTED</span><h1>Community & support</h1><p>Discover ways to give, receive support, and make a difference.</p></div><div className="community-hero"><div><span className="eyebrow light">SMALL ACTIONS, BIG IMPACT</span><h2>Find your way to help.</h2><p>Connect with approved community organisations, donation drives, and volunteering opportunities.</p><button className="light-btn" onClick={()=>navigate("Live Map")}>Explore on the map <MapPin size={16}/></button></div><div className="community-art"><HeartHandshake size={76}/><span className="community-bubble bubble-a"><Heart size={18}/></span><span className="community-bubble bubble-b"><Leaf size={18}/></span></div></div><div className="service-grid">{orderedServices.filter(s=>["blood","food","volunteer"].includes(s.id)).map(renderServiceCard)}</div><div className="safety-note"><ShieldCheck size={18}/><div><strong>Safe, verified community support</strong><p>Food distribution and donation activities should be coordinated through approved organisations. Confirm event details, food safety, and eligibility with organisers.</p></div></div></section>}
        {page==="Study Hub"&&<section className="content-page"><div className="page-intro"><span className="eyebrow"><GraduationCap size={14}/> YOUR LEARNING SPACE</span><h1>Study smarter with Sila</h1><p>Make a revision plan, practise what you know, and find your next learning opportunity.</p></div><div className="study-hero"><div><span className="eyebrow light">YOUR PERSONAL STUDY BUDDY</span><h2>One step at a time.</h2><p>Tell Sila what you're studying and when your exam is. Get a practical revision plan and practice ideas.</p><button className="light-btn" onClick={()=>{setChatInput("Help me make a study plan for my next exam.");navigate("AI Assistant")}}>Create a study plan <ArrowRight size={16}/></button></div><div className="study-illustration"><BookOpen size={66}/><GraduationCap size={42}/><Sparkles size={25}/></div></div><div className="study-tools"><button className="study-tool" onClick={()=>askSila("Help me make a study plan for my next exam.")}><div className="quick-icon violet"><CalendarDays/></div><strong>Revision planner</strong><p>Organise topics and time.</p><span>Build my plan <ArrowRight size={14}/></span></button><button className="study-tool" onClick={()=>askSila("Create practice questions for my subject.")}><div className="quick-icon blue"><BookOpen/></div><strong>Practice questions</strong><p>Check your understanding.</p><span>Start practising <ArrowRight size={14}/></span></button><button className="study-tool" onClick={()=>{setQuery("tutor");navigate("Services")}}><div className="quick-icon green"><Users/></div><strong>Find a tutor</strong><p>Explore learning support.</p><span>Browse tutors <ArrowRight size={14}/></span></button></div></section>}
        {page==="Local Life"&&<section className="content-page"><div className="page-intro"><span className="eyebrow"><Building2 size={14}/> AROUND YOUR COMMUNITY</span><h1>Local life, connected</h1><p>Discover local businesses, mechanics, tutors, and useful places.</p></div><div className="search-toolbar"><div className="search-field"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search garages, tutors, shops..."/></div><button className="secondary-btn" onClick={()=>navigate("Live Map")}><MapPin size={16}/> Explore map</button></div><div className="service-grid">{orderedServices.filter(s=>["business","tutors","transport","travel"].includes(s.id)).filter(s=>`${s.title} ${s.desc}`.toLowerCase().includes(query.toLowerCase())).map(renderServiceCard)}</div></section>}
        {page==="Saved"&&<section className="content-page"><div className="page-intro"><span className="eyebrow"><Bookmark size={14}/> YOUR COLLECTION</span><h1>Saved for later</h1><p>Keep useful services close at hand.</p></div>{saved.length?<div className="service-grid">{services.filter(s=>saved.includes(s.id)).map(renderServiceCard)}</div>:<div className="empty-state"><Bookmark size={32}/><h3>Your saved list starts here</h3><p>Save services using the bookmark icon to find them quickly later.</p><button className="primary-btn" onClick={()=>navigate("Services")}>Explore services <ArrowRight size={16}/></button></div>}</section>}
        {page==="Profile"&&<section className="content-page"><div className="page-intro"><span className="eyebrow"><Settings size={14}/> YOUR PREFERENCES</span><h1>Profile & settings</h1><p>Make your Sila experience feel like yours.</p></div><div className="profile-layout"><div className="profile-card panel"><div className="profile-avatar"><UserRound size={35}/></div><h2>{accountType==="visitor"?"UAE Visitor":"Sila Explorer"}</h2><p className="muted">{accountType==="visitor"?"Visitor / Tourist":"UAE Resident"} · Demo profile</p><div className="profile-divider"></div><label className="field-label">Account type</label><div className="language-options"><button className={accountType==="resident"?"language-option chosen":"language-option"} onClick={()=>setAccountType("resident")}><House size={17}/> Resident</button><button className={accountType==="visitor"?"language-option chosen":"language-option"} onClick={()=>setAccountType("visitor")}><Plane size={17}/> Visitor</button></div><label className="field-label">Language</label><div className="language-options"><button className={language==="en"?"language-option chosen":"language-option"} onClick={()=>setLanguage("en")}>🇬🇧 English</button><button className={language==="ar"?"language-option chosen":"language-option"} onClick={()=>setLanguage("ar")}>🇦🇪 العربية</button></div><button className="secondary-btn full" onClick={()=>setNotice("Profile changes are active for this session only. Add a secure backend to save them permanently.")}>Save preferences <Check size={16}/></button></div><div className="settings-panel panel"><h3>Personalisation & privacy</h3>{[{icon:Sparkles,title:"Personalised recommendations",desc:"Prioritise services based on your selected account type."},{icon:ShieldCheck,title:"Privacy-first demo",desc:"This prototype doesn't save your phone number to a database."},{icon:Bell,title:"Reminders",desc:"Real notifications require a secure backend and your permission."}].map(x=>{const Icon=x.icon;return <div className="setting-row" key={x.title}><div className="setting-icon"><Icon size={19}/></div><div><strong>{x.title}</strong><p>{x.desc}</p></div><CheckCircle2 size={18} className="setting-check"/></div>})}<div className="settings-warning"><HelpCircle size={17}/> Demo account settings reset when the page is refreshed.</div></div></div></section>}
        {notice&&<div className="toast"><HelpCircle size={17}/><span>{notice}</span><button onClick={()=>setNotice("")}><X size={16}/></button></div>}
        <footer className="app-footer"><span>© 2026 Sila OS</span><span>Prototype · Always verify official requirements</span><button onClick={()=>navigate("Profile")}>Privacy & settings</button></footer>
      </div>
    </main>
    {selected&&<div className="modal-backdrop" onClick={()=>setSelected(null)}><div className="service-modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setSelected(null)}><X size={20}/></button><div className={`service-icon large ${selected.color}`}><selected.icon size={28}/></div><span className="eyebrow">{selected.category}</span><h2>{selected.title}</h2><p>{selected.desc}</p><div className="modal-info"><div><ShieldCheck size={18}/><span><strong>Verify requirements</strong><small>Confirm eligibility and details with the official authority.</small></span></div><div><FileText size={18}/><span><strong>Prepare your checklist</strong><small>Gather documents only after confirming the current requirements.</small></span></div><div><ExternalLink size={18}/><span><strong>Official channel</strong><small>Add the verified official application URL before launch.</small></span></div></div><div className="modal-actions"><button className="secondary-btn" onClick={()=>toggleSave(selected.id)}><Bookmark size={16}/>{saved.includes(selected.id)?"Remove saved":"Save service"}</button><button className="primary-btn" onClick={()=>{askSila(`Help me with ${selected.title.toLowerCase()}.`);setSelected(null)}}>Ask Sila for help <ArrowRight size={16}/></button></div><p className="tiny-note">This prototype does not submit applications or confirm official eligibility.</p></div></div>}
  </div>;
}

function HeartPulseIcon() { return <Activity size={23}/>; }

createRoot(document.getElementById("root")).render(<App />);
